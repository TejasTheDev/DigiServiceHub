+<?php 

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: 1001/index.php");
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DIGI SERVICE HUB</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- font awesome icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <!-- <link href="style.css" rel="stylesheet"> -->


</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center ">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1><a href="main.php">Digi Service Hub</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="main.php">Home</a></li>
          <li class="dropdown"><a class="nav-link scrollto" href="#">Primary Services</a>
            <ul>
              <li><a href="P_Dairy products.html">Dairy Products</a></li>
              <li><a href="P_retail_shop.html">Groceries</a></li>
              <li><a href="P_fruits&vegies.html">Fruits & Veggies</a></li>
              <li class="dropdown"><a href="#"><span style="color:#000;">Hotels</span> <i class="bi bi-chevron-right"></i></a>
                    <ul>
                      <li><a href="P_veg_hotel.html">Veg</a></li>
                      <li><a href="P_nonveg_hotel.html">Non-Veg</a></li>
                    </ul>
                  </li>
              </li>
              <li><a href="P_super_market.html">Super Market</a></li>
              <!-- <li><a href="#">See More</a></li> -->
            </ul>
          </li>
          <li class="dropdown"><a class="nav-link scrollto" href="#">Skilled Workers</a>
            <ul>
               <li><a href="S_carpenter.html">Carpenters</a></li>
               <li><a href="S_electronics.html">Electricians</a></li>
               <li><a href="S_plumbers.html">Plumbers</a></li>
               <li><a href="S_painters.html">Painters</a></li>
               <li><a href="S_beauticians.html">Beauticians</a></li>
               <!-- <li><a href="S_nurses.html">Nurses</a></li> -->
               <li><a href="S_mechanics.html">Mechanics</a></li>
               <!-- <li><a href="S_goldsmiths.html">Goldsmiths</a></li> -->
            </ul>
          </li>
          <li class="dropdown"><a class="nav-link scrollto" href="#">Medical Service</a>
            <ul>
              <li><a href="M_hospitals.html">Hospitals</a></li>
              <li><a href="M_pharmacy.html">Pharmacies</a></li>
              <li><a href="M_blood_Banks.html">Blood Banks</a></li>
              <li><a href="M_scanning_Center.html">Scanning Centers</a></li>
              <!-- <li><a href="M_ambulance.html">Ambulance</a></li> -->
              <!-- <li><a href="M_nurses.html">Nurses</a></li> -->
              <li><a href="M_clinics.html">Clinics</a></li>
            </ul>
          </li>
          <li><a href="G_government.html">Government Service</a></li>
          <li><a href="about us.html">About Us</a>
          <li><a href="logout.php">Logout</a>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
    </div>
  </header><!-- End Header -->
  <br><br><br>
  <!-- carousel -->
  <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" data-interval="1000" data-pause="hover">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active" >
        <img class="img" src="carisole/c1.jpeg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img class="img" src="carisole/c3.jpeg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img class="img" src="carisole/c4.jpeg" class="d-block w-100" alt="...">
      </div>
    </div>  
</div>
<!--  End of carousel  -->
   <!-- para start -->

   <div class="para col-md-12">
    <p class="para1">Digi Service Hub is a service oriented platform that is providing a service of grouping all the services 
        needed to a person in a city for his daily life. 
        We provide all the information You need about the services available in Hassan.</p>


       <p class="para1"> You can get all the information from us based on the below classifications:
    </p>
    </div>

<!-- para end -->

<!-- css info box start -->
<section>
<div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-2">
  <div class="col">
    <div class="card">
      <img src="assets/img/primary.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Primary Services</h5>
        <p class="card-text">Under Primary Services you can get all the basic essential services for daily life like grocery Stores
          Hotels, Vegetable and Fruits stores and many more.
      </p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="assets/img/skill.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Skilled Services</h5>
        <p class="card-text">Under the skilled craftsmen section you can hire the required skill persons to 
          your work according to your needs.
      </p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="assets/img/med.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Medical Service</h5>
        <p class="card-text">Under the medical services you get information about the hospitals, blood banks, 
          pharmacies etc available around you.
      </p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="assets/img/govt.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Government Service</h5>
        <p class="card-text">Under the government services you can get to know about the government offices 
          located in the city and their addresses.
      </p>
      </div>
    </div>
  </div>
</div>
  </section>
<!-- end of css info box -->

<!-- start join now -->

<div class="para col-md-12 cent" >
  <p class="para1">Interested to provide your service at Digi Service Hub??<br>
     Join today and start providing your services now!!!!!!!!!!!</p>
     <a href="embed.html"><button class="btn btn-outline-danger">Join as a Service Provider</button></a>
 </div>
<!-- ends join now-->

<!-- footer start -->

<footer>
  <div id="contact">
     <div class="footer">
        <div class="container">
        
           <div class="row">
              
              <div class="col-md-9">
                 
              </div>
              
              <div class="col-md-4 col-sm-6">
                <div class="Informa helpful">
                   <h3>Useful  Links</h3>
                   <ul>
                      <li><a href="main.php">Home</a></li>
                      <li><a href="P_Dairy products.html">Primary Services</a></li>   
                      <li><a href="S_carpenter.html">Skilled Services</a></li>
                      <li><a href="M_hospitals.html">Medical Services</a></li>
                      <li><a href="G_Government.html">Government Services</a></li>
                      <li><a href="about us.html">About us</a></li>
                   </ul>
                </div>
             </div>
              
              <div class="col-md-4 col-sm-6">
                 <div class="Informa">
                    <h3>Us</h3>
                    <ul>
                       <li>Digi Service Hub is a                             
                       </li>
                       <li>Sevice oriented website                            
                       </li>
                       <li>providing service for the                          
                       </li>
                       <li>people at their fingertips                              
                       </li>
                       <li>in Hassan City.                          
                       </li>
                    </ul>
                 </div>
              </div>
              <div class="col-md-4 col-sm-6">
                 <div class="Informa conta">
                    <h3>Contact Us</h3>
                    <ul>
                        <li><b> Digi Service Hub</b></li>
                       
                       <li> <a href="Javascript:void(0)"><i class="fa fa-phone" aria-hidden="true"></i> Call +91 8277699732
                          </a>
                       </li>
                       <li> <a href="mailto:digiservicehub@gmail.com?subject = Enquiry" target="blank"> <i class="fa fa-envelope" aria-hidden="true"></i> digiservicehub@gmail.com
                          </a>
                       </li>
                       <li> <a href="https://wa.me/918277699732/?text=Hello%20Digi%20Service%20Hub"target="blank"><i class="fa fa-whatsapp" aria-hidden="true"></i>  +91 8277699732
                          </a>
                       </li>
                    </ul>
                 </div>
              </div>
           </div>
        </div>
        
        
        
        
        <div class="copyright text_align_left">
           <div class="container">
              <div class="row d_flex">
                 <div class="col-md-4">
                    <p>© 2021 All Rights Reserved.  <a href="https://html.design/"> Digi Service Hub</a></p>
                 </div>
                 <div class="col-sm-2">
                  <!-- <i class="fa fa-whatsapp" aria-hidden="true"></i> -->
                  <!-- <i class="fa fa-facebook" aria-hidden="true"></i> -->
                  <!-- <i class="fa fa-instagram" aria-hidden="true"></i> -->
                  <!-- <i class="fa fa-twitter" aria-hidden="true"></i> -->
                 </div>
              </div>
           </div>
        </div>
     </div>
  </footer>
<!-- end of footer -->


  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>